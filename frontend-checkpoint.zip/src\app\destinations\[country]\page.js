import { destinationsData } from '@/data/destinations';
import Link from 'next/link';

export default function CountryPage({ params }) {
  const countryId = params.country;
  const destination = destinationsData.find(d => d.id === countryId);

  if (!destination) {
    return (
      <div className="container" style={{ padding: '10rem 1.5rem', textAlign: 'center' }}>
        <h1>Destination Not Found</h1>
        <p style={{ marginTop: '1rem' }}>The country you are looking for does not exist in our database.</p>
        <Link href="/destinations" className="btn-primary" style={{ marginTop: '2rem' }}>Back to Destinations</Link>
      </div>
    );
  }

  return (
    <div className="destination-detail-page">
      {/* Hero Section */}
      <div className="dest-hero" style={{ 
        backgroundImage: `url("${destination.image}")`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        position: 'relative',
        padding: '8rem 0 6rem 0',
        color: 'white'
      }}>
        <div className="dest-hero-overlay" style={{
          position: 'absolute',
          inset: 0,
          backgroundColor: 'rgba(0,0,0,0.6)',
          zIndex: 1
        }}></div>
        <div className="container dest-hero-content text-center" style={{ position: 'relative', zIndex: 2 }}>
          <h1 style={{ fontSize: '3rem', marginBottom: '1rem' }}>Study in {destination.name}</h1>
          <p className="subtitle" style={{ fontSize: '1.25rem', opacity: 0.9 }}>Your ultimate guide to world-class education</p>
        </div>
      </div>

      {/* Content Section */}
      <div className="container section" style={{ padding: '5rem 1.5rem' }}>
        <div className="grid grid-cols-3">
          
          <div className="main-content" style={{ gridColumn: 'span 2' }}>
            <h2 style={{ fontSize: '2rem', marginBottom: '1.5rem', color: 'var(--secondary)' }}>Why Study in {destination.name}?</h2>
            <p style={{ fontSize: '1.1rem', lineHeight: '1.8', color: 'var(--text-muted)', marginBottom: '2.5rem' }}>
              {destination.description} {destination.name} has long been a top choice for international students offering a unique blend of cultural experiences, excellent academic institutions, and a thriving post-graduation career landscape. Start your journey today and unlock immense career opportunities globally.
            </p>
            
            <h3 style={{ fontSize: '1.5rem', marginBottom: '1rem', color: 'var(--secondary)' }}>Key Benefits</h3>
            <ul className="benefit-list" style={{ listStyle: 'none', padding: 0, marginBottom: '2.5rem' }}>
              {destination.points.map((pt, i) => (
                <li key={i} style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.75rem', fontSize: '1.05rem', color: 'var(--text-main)' }}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  {pt}
                </li>
              ))}
            </ul>

            <h3 style={{ fontSize: '1.5rem', marginBottom: '1rem', color: 'var(--secondary)' }}>Popular Courses</h3>
            <p style={{ color: 'var(--text-muted)', lineHeight: '1.6' }}>
              From Business and Management to Engineering, IT, and Healthcare, universities in {destination.name} offer diverse programs tailored to modern industry demands. Global Village Academy provides personalized counseling to match your academic background with the perfect university and course.
            </p>
          </div>

          {/* Sidebar CTA */}
          <div className="sidebar" style={{ alignSelf: 'start' }}>
            <div className="cta-card text-center" style={{ background: 'var(--bg-light)', padding: '2.5rem 1.5rem', borderRadius: 'var(--radius-lg)', border: '1px solid #E2E8F0', position: 'sticky', top: '100px' }}>
              <h3 style={{ marginBottom: '1rem', fontSize: '1.25rem', color: 'var(--secondary)' }}>Ready to Apply?</h3>
              <p style={{ color: 'var(--text-muted)', marginBottom: '1.5rem', fontSize: '0.95rem', lineHeight: '1.5' }}>
                Our expert counselors are here to help you secure your admission and student visa for {destination.name}.
              </p>
              <Link href="/consultation" className="btn-primary" style={{ width: '100%', display: 'block' }}>Book Free Consultation</Link>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  );
}
